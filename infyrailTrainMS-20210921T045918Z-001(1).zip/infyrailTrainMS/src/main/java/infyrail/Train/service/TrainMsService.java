package infyrail.Train.service;
import java.util.List;
import infyrail.Train.dto.TrainMsDto;
import infyrail.Train.dto.TrainUpdate;

public interface TrainMsService {
public int createTrain(TrainMsDto dto);
public String updateFare(int id,TrainUpdate fare);
public List<TrainMsDto> getTrainByRouteId(int routeId);
public String deleteTrain(int rid,int id);
public void updateTrainDetailsByRouteId(int id, List<TrainMsDto> Traindetails);

}
