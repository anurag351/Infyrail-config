package infyrail.Route.Dto;
import infyrail.Route.Dto.TrainMsDto;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import infyrail.Route.entity.Route;

public class RouteMsDto {
	private int Id;
	@NotEmpty(message="{route.source1.must}")
	@Pattern(regexp="[a-zA-z]{1,}",message= "{route.source.must}")

	private String Source;
	@NotEmpty
	@Pattern(regexp="[a-zA-z]{1,}",message="{route.destination.must}")
	private String Destination;
	
	public RouteMsDto() {
		super();
	}

	public RouteMsDto(int id, String source, String destination) {
		super();
		Id = id;
		Source = source;
		Destination = destination;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getSource() {
		return Source;
	}

	public void setSource(String source) {
		Source = source;
	}

	public String getDestination() {
		return Destination;
	}

	public void setDestination(String destination) {
		Destination = destination;
	}

	public static Route prepareEntity(RouteMsDto dto)
	{
		Route route=new Route();
		route.setId(dto.getId());
		route.setDestination(dto.getDestination());
		route.setSource(dto.getSource());
		return route;
	}
	public static RouteMsDto prepareDto(Route route)
	{
		RouteMsDto dto=new RouteMsDto();
		dto.setId(route.getId());
		dto.setDestination(route.getDestination());
		dto.setSource(route.getSource());
		return dto;
	}
}
