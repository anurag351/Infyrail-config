package infyrail.Route.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Route")
public class Route 
{
	
	@Id
	@GeneratedValue(generator = "mySeqGen")
	@SequenceGenerator(name = "mySeqGen", sequenceName = "mySeq", initialValue =100)
	private int id;
	@Column
	private String source;
	@Column
	private String destination;
	public Route() {
		super();
	}
	public Route(int id, String source, String destination) {
		super();
		this.id = id;
		this.source = source;
		this.destination = destination;
	}
	public int getId() {
		return this.id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSource() {
		return this.source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return this.destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	@Override
	public String toString() {
		return "Route [Id=" + id + ", Source=" + source + ", Destination=" + destination + "]";
	}
	
}
