package infyrail.Route.util;

public enum infyrailRouteConstants {
	GENERAL_EXCEPTION_MESSAGE("general.exception");
	
	private final String type;
	private infyrailRouteConstants(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return this.type;
	}
}
